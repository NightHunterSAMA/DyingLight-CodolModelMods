1.将NightSama_Model这一整个文件夹放入消光根目录下的DW/Data文件内
2.将必要文件放入到内置即可，建议使用纯净内置否则会导致无法生效！

此文件已在Github仓库上传完成!!! 如下链接直达!
https://github.com/NightHunterSAMA/DyingLight-CodolModelMods


---Original Author By NightSAMA - Bilibili - NightHunterMM
哔哩哔哩：猎手妹妹
—①群：1170133873
https:jq.qq.com?_wv=1027&k=3yNskkJR
—②群：289484516
https:jq.qq.com?_wv=1027&k=0K1JGrQs
—③群：1030279220
https:jq.qq.com?_wv=1027&k=2iWUIkrJ
—④群：736695797
https:jq.qq.com?_wv=1027&k=m5qoC2MP
未经授权禁止转载，禁止用于非法用途传播使用等！